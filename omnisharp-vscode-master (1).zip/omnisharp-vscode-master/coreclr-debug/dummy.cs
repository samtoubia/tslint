using System;

namespace Dummy
{
    class Dummy
    {
        static void Main(string[] args) {
            // empty boilerplate required by dotnet build/publish to emit an entry point
            // The entrypoint created is dummy[.exe], which we rename to OpenDebugAD7[.exe]
            // The generated entry point will then run OpenDebugAD7.dll for us
        }
    }
}